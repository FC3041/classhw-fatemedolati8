
// version temp

(()=>{
    var s=document.createElement("script");s.src="https://van.najva.com/static/js/main-script.js";s.defer=!0;s.id="najva-mini-script";s.setAttribute("data-najva-id","9518fbad-214c-4dd4-8e5d-515aaf983748");document.head.appendChild(s);
})();
