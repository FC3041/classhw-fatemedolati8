let offcanvas, backdrop, hamburger, first_open = true,
    body = jQuery('body'), modalsList = [];

/* -------------------------offcanvas------------------------ */
const offcanvasToggle = () => {
    hamburger.toggleClass('close');
    backdrop_toggle();
    first_open && offcanvas.removeClass('d-none');
    setTimeout(() => {
        offcanvas.toggleClass('show');
    }, 0);
    first_open = false;
}
const offcanvas_close = () => {
    offcanvas.removeClass('show');
    hamburger.removeClass('close');
    backdropHide();
}
function backdropHide() {
    body = jQuery('body');
    backdrop.fadeOut('fast').removeClass('show');;
    body.removeClass('overflow-hidden');
}
function backdrop_toggle() {
    body = jQuery('body')
    backdrop.fadeToggle('fast').toggleClass('show');
    body.toggleClass('overflow-hidden');
}

/* -------------------------accordion------------------------ */
const dropMenu_close = () => {
    jQuery('#offcanvas .dropMenu').each(function() {
        let _this = jQuery(this);
        const target = _this.attr('data-submenu_id');
        setTimeout(() => {
            accordion_toggle(_this, target, 330, 0, false, 'up');
            _this.toggleClass('expanded collapsed');
            accordion_collapse();
        }, 200);
    });
}
function accordion_collapse() {
    let _this = jQuery(this),
        target = _this.attr('data-accord-id');
    accordion_toggle(_this, target, 350, 0, false);
    _this.removeClass('expanded');
}
function accordion_toggle(_this, target, transTime, offsetTop, offset= true, toggleMode = 'toggle') {
    _this.find('.arrow-down').toggleClass('rotate-arrow-up');
    if (offset)
        // :visible checks if the target is visible or not(checks css display).
        if (!jQuery(`${target}:visible`).length) {
            let offset = _this.offset();
            offset.top -= offsetTop;
            jQuery('html, body').animate({scrollTop: offset.top}, 70);
        }   // executes when accordion content is hidden
    if (toggleMode === 'toggle')
        jQuery(target).slideToggle(transTime);
    else if (toggleMode === 'up')
        jQuery(target).slideUp(transTime);
    else if (toggleMode === 'down')
        jQuery(target).slideDown(transTime);
}


jQuery(() => {
    offcanvas = jQuery('#offcanvas');
    hamburger = jQuery('.menu-mobile-opener');
    backdrop = jQuery('.backdrop');
    let accordion = jQuery('.accordionWrap'), accordionBtn = jQuery('.accord-button');

    // click event on hamburger icon to toggle offcanvas
    offcanvas.length && hamburger.on('click', offcanvasToggle);

    jQuery('.backdrop, .offcanvasClose').on('click', function() {
        if (offcanvas.hasClass('show')) {
            offcanvas_close();
            // backdropHide();
            dropMenu_close();      // closes all dropdown menus
            // closes all accordions
            jQuery('#offcanvas .accord-button.expanded').each(function() {
                accordion_collapse.call(this);
            });
        }
    });
    // toggles the dropdown items
    jQuery('.dropMenu').on('click', function() {
        jQuery(this).toggleClass('collapsed expanded');  // toggle collapsed class to expanded
        let target = jQuery(this).attr('data-submenu_id');
        accordion_toggle(jQuery(this), target, 330, 0, false);
    });
    // toggles the accordion items, closes the other items
    accordion.on('click', '.accord-button', function() {
        let _this = jQuery(this),
            accordionWrap = _this.closest('.accordionWrap');
        // first close expanded items, then open the clicked item
        if (!_this.hasClass('expanded')) {
            if (accordionWrap.find('.accord-button.expanded').length) {
                accordionWrap.find('.accord-button.expanded').each(function() {
                    accordion_collapse.call(this);
                });
            }
        }
        // open the clicked item
        let target = _this.attr('data-accord-id');
        accordion_toggle(_this, target, 350, 0, false);
        _this.toggleClass('expanded');
    });
    jQuery('.search-input-global').focus(function() {
        jQuery(this).parent().addClass('highlight-border');
      });
      // When input is blurred
    jQuery('input').blur(function() {
        jQuery(this).parent().removeClass('highlight-border');
    });
    jQuery('.global-search-btn').click(function(){
        setTimeout(function () {
            jQuery("#search-input-global").focus();
        }
        ,500)
    });
});

