jQuery('document').ready(function () {

    jQuery(".top-nav ul>li:nth-child(1) > a").prepend('<svg xmlns="http://www.w3.org/2000/svg" width="16.221" height="13.788" viewBox="0 0 16.221 13.788">\n' +
        '  <path id="ic_home_24px" d="M8.488,16.788V11.921h3.244v4.866h4.055V10.3h2.433L10.11,3,2,10.3H4.433v6.488Z" transform="translate(-2 -3)" fill="#546b7c"/>\n' +
        '</svg>\n');
    jQuery(".top-nav ul>li:nth-child(2) > a").prepend('    <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 14 14">      <g id="Group_738" data-name="Group 738" transform="translate(0.156 -0.019)">        <g id="Group_737" data-name="Group 737" transform="translate(-0.156)">          <rect id="Rectangle_679" data-name="Rectangle 679" width="6" height="6" rx="1" transform="translate(0 8.019)" fill="#546b7c"/>          <rect id="Rectangle_680" data-name="Rectangle 680" width="6" height="6" rx="1" transform="translate(8 0.019)" fill="#546b7c"/>         <circle id="Ellipse_54" data-name="Ellipse 54" cx="3" cy="3" r="3" transform="translate(8 8.019)" fill="#546b7c"/>          <circle id="Ellipse_55" data-name="Ellipse 55" cx="3" cy="3" r="3" transform="translate(0 0.019)" fill="#546b7c"/>        </g>      </g>    </svg>    ');
    jQuery(".top-nav ul>li:nth-child(3) > a").prepend('<svg xmlns="http://www.w3.org/2000/svg" width="17.273" height="13.348" viewBox="0 0 17.273 13.348">  <path id="ic_import_contacts_24px"d="M16.7,4.893A9.269,9.269,0,0,0,13.955,4.5,7.3,7.3,0,0,0,9.637,5.678,7.3,7.3,0,0,0,5.318,4.5,7.3,7.3,0,0,0,1,5.678v11.5a.422.422,0,0,0,.393.393c.079,0,.118-.039.2-.039a9.583,9.583,0,0,1,3.729-.864,7.3,7.3,0,0,1,4.318,1.178,9.457,9.457,0,0,1,4.318-1.178,7.992,7.992,0,0,1,3.729.824.354.354,0,0,0,.2.039.422.422,0,0,0,.393-.393V5.678A5.355,5.355,0,0,0,16.7,4.893Zm0,10.6a9.124,9.124,0,0,0-2.748-.393,9.457,9.457,0,0,0-4.318,1.178V7.248A9.457,9.457,0,0,1,13.955,6.07a9.124,9.124,0,0,1,2.748.393Z" transform="translate(-1 -4.5)" fill="#546b7c"/></svg>');
    jQuery(".top-nav ul>li:nth-child(4) > a").prepend('<svg width="23" height="14" viewBox="0 0 23 14" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M12.6131 2.33557C12.6131 2.12933 12.6912 1.93153 12.8304 1.7857C12.9695 1.63987 13.1582 1.55794 13.355 1.55794H22.2581C22.4548 1.55794 22.6436 1.63987 22.7827 1.7857C22.9218 1.93153 23 2.12933 23 2.33557C23 2.54181 22.9218 2.7396 22.7827 2.88543C22.6436 3.03127 22.4548 3.1132 22.2581 3.1132H13.355C13.1582 3.1132 12.9695 3.03127 12.8304 2.88543C12.6912 2.7396 12.6131 2.54181 12.6131 2.33557ZM22.2581 6.22371H13.355C13.1582 6.22371 12.9695 6.30564 12.8304 6.45147C12.6912 6.59731 12.6131 6.7951 12.6131 7.00134C12.6131 7.20758 12.6912 7.40537 12.8304 7.55121C12.9695 7.69704 13.1582 7.77897 13.355 7.77897H22.2581C22.4548 7.77897 22.6436 7.69704 22.7827 7.55121C22.9218 7.40537 23 7.20758 23 7.00134C23 6.7951 22.9218 6.59731 22.7827 6.45147C22.6436 6.30564 22.4548 6.22371 22.2581 6.22371ZM22.2581 10.8895H15.5808C15.384 10.8895 15.1953 10.9714 15.0561 11.1172C14.917 11.2631 14.8388 11.4609 14.8388 11.6671C14.8388 11.8734 14.917 12.0711 15.0561 12.217C15.1953 12.3628 15.384 12.4447 15.5808 12.4447H22.2581C22.4548 12.4447 22.6436 12.3628 22.7827 12.217C22.9218 12.0711 23 11.8734 23 11.6671C23 11.4609 22.9218 11.2631 22.7827 11.1172C22.6436 10.9714 22.4548 10.8895 22.2581 10.8895ZM9.39405 8.36219C10.1304 7.76775 10.6707 6.94666 10.9393 6.01406C11.2079 5.08147 11.1912 4.08415 10.8917 3.16198C10.5921 2.23981 10.0247 1.43904 9.26896 0.871975C8.51323 0.304913 7.60711 0 6.67769 0C5.74826 0 4.84214 0.304913 4.08641 0.871975C3.33068 1.43904 2.76325 2.23981 2.46369 3.16198C2.16414 4.08415 2.14748 5.08147 2.41606 6.01406C2.68464 6.94666 3.22499 7.76775 3.96132 8.36219C2.04901 9.21078 0.541978 10.9186 0.0235592 13.028C-0.0047564 13.1429 -0.00758789 13.2631 0.0152817 13.3794C0.0381513 13.4957 0.0861147 13.6049 0.155496 13.6987C0.224877 13.7926 0.313834 13.8685 0.415549 13.9207C0.517263 13.9729 0.629035 14.0001 0.742297 14H12.6131C12.7263 14.0001 12.8381 13.9729 12.9398 13.9207C13.0415 13.8685 13.1305 13.7926 13.1999 13.6987C13.2693 13.6049 13.3172 13.4957 13.3401 13.3794C13.363 13.2631 13.3601 13.1429 13.3318 13.028C12.8134 10.9177 11.3064 9.20981 9.39405 8.36219Z" fill="#546b7c"/></svg>');

    jQuery('.submenu-pc .menu-side-right .items').hover(function () {
        var a = jQuery(this).attr('class');
        jQuery('.submenu-pc .menu-side-right .items.active').attr('class', 'items');
        jQuery(this).attr('class', a + " active");
        var blk = jQuery(this).attr('data-p');
        jQuery('.bxs').hide();
        jQuery('.' + blk).show();
    });

    jQuery('.sub-menu-dark').mouseover(function () {
        hide_submenu("#submenu-main");
        hide_submenu("#submenu-mag");
    });

    

    jQuery('#menu-menu-1 > li').not('#menu-menu-1 > li:eq(1)').mouseover(function () { hide_submenu("#submenu-main") });
    jQuery('#menu-menu-1 > li').not('#menu-menu-1 > li:eq(2)').mouseover(function () { hide_submenu("#submenu-mag") });
    
    jQuery('#menu-menu-1 > li').eq(1).mouseover(function () { show_submenu("#submenu-main"); });
    jQuery('#menu-menu-1 > li').eq(2).mouseover(function () { show_submenu("#submenu-mag",290, 776); });

    jQuery(window).scroll(function () {
        hide_submenu("#submenu-main");
        hide_submenu("#submenu-mag");
    });
});

function show_submenu(el_selector,height=289, width=972) {
    console.log(el_selector);
    jQuery('.sub-menu-dark').show();
    jQuery(el_selector).show();
    
    jQuery(el_selector).height(height);
    jQuery(el_selector).width(width);
}

function hide_submenu(el_selector) {
    jQuery('.sub-menu-dark').hide();
    jQuery(el_selector).hide();
    jQuery(el_selector).height(0);
    jQuery(el_selector).width(0);
}